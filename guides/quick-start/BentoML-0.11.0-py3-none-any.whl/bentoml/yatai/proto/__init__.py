__all__ = [
    "deployment_pb2",
    "label_selectors_pb2",
    "repository_pb2",
    "status_pb2",
    "yatai_service_pb2",
    "yatai_service_pb2_grpc",
]
